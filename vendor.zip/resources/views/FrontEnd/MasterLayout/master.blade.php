@yield('header')
@yield('slider')
@yield('banner')
@yield('topSellingProducts')

@yield('banner2')

@yield('featuredProducts')

@yield('partners')


@yield('blogsection')


@yield('footer')
