@yield('header')
@yield('sidebar')
@yield('dashboard')
@yield('footer')

